from django.contrib import admin

from .models import (Order, Plan, SocialAccount, Subscription,
                     UserSocialAccount, UserSocialAccountPost,
                     UserSocialAccountPostMedia)

admin.site.register(Plan)
admin.site.register(Order)
admin.site.register(Subscription)
admin.site.register(UserSocialAccount)
admin.site.register(UserSocialAccountPost)
admin.site.register(UserSocialAccountPostMedia)
admin.site.register(SocialAccount)