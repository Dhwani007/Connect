from django.urls import path
from .views import *
urlpatterns = [
    path('', index, name='index'),
    #  path('plans/', plans, name='plans'),
    path('planlist/', planslist, name='PlansList'),
    path('paymenthandler/', paymenthandler, name='paymenthandler'),
    path('register/', user_register, name='register'),
    path('login/', user_login, name='login'),
    path("logout/", user_logout, name="logout"),
    path('payment/<int:id>/', payment, name='payment'),
    path('postlist/', postlist, name='postlist'),
    path('listpost/', listpost, name='listpost'),
    path('post_create/', post_create, name='post_create'),
    path('delete/<int:id>', post_delete, name='delete'),
    path('update/<int:id>', update, name='update'),

]
