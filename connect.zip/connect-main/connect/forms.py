from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Plan, UserSocialAccountPost, UserSocialAccountPostMedia


class PlanForm(forms.ModelForm):
    class Meta:
        model = Plan
        fields = "__all__"


class NewUserForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ("username", "email", "password1", "password2")

    def save(self, commit=True):
        user = super(NewUserForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
            return user


class PostCreate(forms.ModelForm):
    class Meta:
        model = UserSocialAccountPost
        fields = ("user_social_account", "page_id", "content", "schedule_at", "status")


class CreateImage(forms.ModelForm):
    class Meta:
        model = UserSocialAccountPostMedia
        fields = ("user_social_account_post", "media", "media_type")


class PostUpdate(forms.ModelForm):
    class Meta:
        model = UserSocialAccountPost
        fields = ("user_social_account", "page_id", "content", "schedule_at", "status")
