from django.utils import timezone
import tzlocal


class UserTimezoneMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
#
#
#         if request.session.get('detected_tz'): # (set by django-tz-detect)
#             tz = timezone.get_current_timezone()
#             print("================",tz)
#             print("*********************",request.session.get('detected_tz'))
#
#
#         local_timezone = tzlocal.get_localzone()
#         print("local_timeze========>", local_timezone)

        if request.session.get('detected_tz'): # (set by django-tz-detect)

            tz = timezone.get_current_timezone()
            print("-----------------------------------",tz)
        return response









