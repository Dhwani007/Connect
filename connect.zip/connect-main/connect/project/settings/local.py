# Celery settings
from .__init__ import *
CELERY_BROKER_URL = os.getenv("CELERY_BROKER_URL", default="redis://localhost:6379")
CELERY_RESULT_BACKEND = os.getenv("CELERY_RESULT_BACKEND", default="redis://localhost:6379")
CELERY_TIMEZONE = os.getenv("CELERY_TIMEZONE", default="UTC")

CELERY_TASK_SERIALIZER = 'json'
CELERY_RESULT_SERIALIZER = 'json'
CELERY_ACCEPT_CONTENT = ['application/json']

# CELERY BEAT
CELERY_BEAT_SCHEDULER = os.environ.get("CELERY_BEAT_SCHEDULER")
