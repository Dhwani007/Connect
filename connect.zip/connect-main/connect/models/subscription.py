from django.db import models
from django.utils.translation import pgettext_lazy
from .base import Base
from .plan import Order


class Subscription(Base):

    order = models.ForeignKey(
        Order,
        related_name="subscriptions",
        on_delete=models.CASCADE
    )
    start_time = models.DateTimeField(
        pgettext_lazy("field", "Start Time"),
    )
    end_time = models.DateTimeField(
        pgettext_lazy("field", "End Time")
    )

    # def __str__(self):
    #     return self.order
