from enum import IntEnum

from django.contrib.auth.models import User
from django.db import models
from django.utils.translation import pgettext_lazy

from .base import Base


class PostDeployStatus(IntEnum):
    SCHEDULED = 1
    POSTED = 2
    FAILED = 3

    @classmethod
    def choices(cls):
        return [(key.value, key.name) for key in cls]


class MediaType(IntEnum):
    IMAGE = 1
    VIDEO = 2

    @classmethod
    def choices(cls):
        return [(key.value, key.name) for key in cls]


class SocialAccount(Base):
    name = models.CharField(
        pgettext_lazy("field", "Social Account Name"),
        max_length=180
    )
    url = models.URLField(
        pgettext_lazy("field", "URL"),
        blank=True,
        null=True
    )
    api_key = models.TextField(
        pgettext_lazy("field", "API Key"),
        blank=True,
        null=True
    )
    api_secret = models.TextField(
        pgettext_lazy("field", "API Secret"),
        blank=True,
        null=True
    )
    is_active = models.BooleanField(
        pgettext_lazy("field", "Is Active"),
        default=False
    )

    def __str__(self):
        return str(self.name)


class UserSocialAccount(Base):
    user = models.ForeignKey(
        User,
        related_name='user_social_accounts',
        on_delete=models.CASCADE
    )
    social_account = models.ForeignKey(
        SocialAccount,
        related_name='social_accounts',
        on_delete=models.CASCADE
    )
    secret_key = models.TextField(
        pgettext_lazy("field", "Secret Key")
    )
    first_name = models.CharField(
        pgettext_lazy("field", "First Name"),
        max_length=180
    )
    last_name = models.CharField(
        pgettext_lazy("field", "Last Name"),
        max_length=180
    )
    email = models.EmailField(
        pgettext_lazy("field", "Email"),
        blank=True,
        unique=True
    )
    image_url = models.URLField(
        pgettext_lazy("field", "Image URL"),
        blank=True,
        null=True
    )

    def __str__(self):
        return str(self.user)


class UserSocialAccountPost(Base):
    objects = None
    user_social_account = models.ForeignKey(
        UserSocialAccount,
        related_name='user_social_account_posts',
        on_delete=models.CASCADE
    )
    page_id = models.CharField(
        pgettext_lazy("field", "Page Id"),
        max_length=180
    )
    content = models.TextField(
        pgettext_lazy("field", "Content"),
        max_length=240,
        blank=True,
        null=True
    )
    schedule_at = models.DateTimeField(
        pgettext_lazy("field", "Schedule At"),
        blank=True,
        null=True
    )

    status = models.IntegerField(
        pgettext_lazy("field", "status"),
        choices=PostDeployStatus.choices(),
        default=PostDeployStatus.SCHEDULED
    )

    def __str__(self):
        return str(self.user_social_account)


class UserSocialAccountPostMedia(Base):
    user_social_account_post = models.ForeignKey(
        UserSocialAccountPost,
        related_name='post_media',
        on_delete=models.CASCADE
    )
    media = models.FileField(
        pgettext_lazy("field", "Media"),
        upload_to='images/'
    )
    media_type = models.IntegerField(
        pgettext_lazy("field", "Media Type"),
        choices=MediaType.choices(),
        default=MediaType.IMAGE
    )