from datetime import timedelta
from enum import IntEnum
from django.contrib.auth.models import User
from django.db import models
from django.utils.translation import pgettext_lazy
from .base import Base


class PlanTypes(IntEnum):
    BASIC = 1

    @classmethod
    def choices(cls):
        return [(key.value, key.name) for key in cls]


class Plan(Base):
    name = models.CharField(
        pgettext_lazy("field", "Plan Name"),
        max_length=180
    )
    price = models.DecimalField(
        pgettext_lazy("field", "Price"),
        max_digits=9,
        decimal_places=2,
        default=100
    )
    plan_type = models.IntegerField(
        pgettext_lazy("field", "Plan Type"),
        choices=PlanTypes.choices(),
        default=PlanTypes.BASIC
    )
    permissions = models.JSONField()
    duration = models.DurationField(default=timedelta(days=30))

    def __str__(self):
        return str(self.name)


class Order(Base):
    user = models.ForeignKey(
        User,
        related_name="user_orders",
        on_delete=models.CASCADE
    )
    plan = models.ForeignKey(
        Plan,
        related_name="plan_orders",
        on_delete=models.CASCADE
    )

    # def __str__(self):
    #     return str(self.plan)
