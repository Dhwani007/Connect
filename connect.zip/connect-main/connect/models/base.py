from django.contrib.auth.models import User
from django.db import models
from django.utils.translation import pgettext_lazy


class Base(models.Model):
    created_at = models.DateTimeField(
        pgettext_lazy("field", "Created at"),
        auto_now_add=True
    )
    updated_at = models.DateTimeField(
        pgettext_lazy("field", "Updated at"),
        auto_now=True
    )
    created_by = models.ForeignKey(
        User,
        related_name="%(class)s_created_by_set",
        on_delete=models.CASCADE
    )
    updated_by = models.ForeignKey(
        User,
        related_name="%(class)s_updated_by_set",
        on_delete=models.CASCADE,
    )

    class Meta:
        abstract = True
