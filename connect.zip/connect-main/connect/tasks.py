from .models import *
from celery import shared_task
import requests
graph_url = 'https://graph.facebook.com/v15.0/'
access_token='EAAIA8WPWiBYBAOYg5wHEz8IuEkZAbycFVJYeCTW2LMZCbe9GxBTvT6OhWIUYzHffn5PXFLg2so9kap08pVkkPLZCAkFyBUa1v0oyMJUbc8d0PqdhJcZAK8BnBQ2tT8sriZBjj2QQb2MYv3wmlzzs03vfe7wVZCZC1gC5p1FRe7zdklJmFP7D8qxdEO8qsvKAk0dk97DZA6B7xZC8dvUnIGDZAM'


@shared_task
# POST Image
def post_image(args):
    usermedia = UserSocialAccountPostMedia.objects.get(id=args)
    print("demo ==============>", usermedia.media.url)
    url = graph_url + usermedia.user_social_account_post.page_id + '/photos?url=' + usermedia.media.url
    param = dict()
    param['access_token'] = access_token
    response = requests.post(url, params=param)
    print(response.json())
